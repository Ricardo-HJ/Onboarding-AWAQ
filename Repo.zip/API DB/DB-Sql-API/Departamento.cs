﻿namespace DB_Sql_API
{
    public class Departamento
    {
        public string departamento {  get; set; }
        public int progreso { get; set; }
    }
}
