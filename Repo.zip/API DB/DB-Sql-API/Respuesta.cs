﻿namespace DB_Sql_API
{
	public class Respuesta
	{
		public int idRespuesta {  get; set; }
		public string respuesta {  get; set; }
		public bool respuestaCorrecta { get; set; }
	}
}
