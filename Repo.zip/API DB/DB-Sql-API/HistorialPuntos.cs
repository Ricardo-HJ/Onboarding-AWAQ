﻿namespace DB_Sql_API
{
    public class HistorialPuntos
    {
        public int puntos {  get; set; }
        public DateOnly fecha { get; set; }
    }
}
