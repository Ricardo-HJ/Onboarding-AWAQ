﻿namespace DB_Sql_API
{
	public class Token
	{
		public string token;
	}
}
