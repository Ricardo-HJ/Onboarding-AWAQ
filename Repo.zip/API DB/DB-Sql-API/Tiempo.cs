﻿namespace DB_Sql_API
{
    public class Tiempo
    {
        public string tiempo {  get; set; }
        public string unidad { get; set; }
    }
}
