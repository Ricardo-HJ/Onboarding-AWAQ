﻿namespace DB_Sql_API
{
    public class PreguntaUsuario
    {
        public string usuario {  get; set; }
        public string minijuego { get; set;}
        public string pregunta { get; set;}
        public int tiempo { get; set;}
        public bool acierto { get; set;}
    }
}
