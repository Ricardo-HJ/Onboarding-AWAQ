﻿namespace DB_Sql_API
{
    public class EstadisticasPregunta
    {
        public string clase { get; set; }
        public int cantidad { get; set; }
    }
}
