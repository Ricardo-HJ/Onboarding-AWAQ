﻿namespace DB_Sql_API
{
    public class Zona
    {
        public string zona { get; set; }
        public int progreso { get; set; }
    }
}
