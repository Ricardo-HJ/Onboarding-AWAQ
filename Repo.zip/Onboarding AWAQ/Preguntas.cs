﻿namespace Onboarding_AWAQ
{
    public class Preguntas
    {
        public string clase {  get; set; }
        public int cantidad {  get; set; }
    }
}
