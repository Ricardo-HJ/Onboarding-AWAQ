﻿namespace Onboarding_AWAQ
{
	public class Usuario
	{
		public int Id { get; set; }
		public string Correo { get; set; }
		public string Nombre { get; set; }
		public string Contrasena { get; set; }
        public bool superUsuario { get; set; }
		public string src {  get; set; }
    }
}
