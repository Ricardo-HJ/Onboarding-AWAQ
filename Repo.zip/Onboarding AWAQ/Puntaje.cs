﻿namespace Onboarding_AWAQ
{
    public class Puntaje
    {
        public string src { get; set; }
        public int position { get; set; }
        public string name { get; set; }
        public int puntaje { get; set; }
        public string tiempoJugado { get; set; }
        public string departamento { get; set; }
        public string terminado { get; set; }
    }
}
