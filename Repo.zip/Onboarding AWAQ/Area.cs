﻿namespace Onboarding_AWAQ
{
    public class Area
    {
        public string zona { get; set; }
        public int progreso { get; set; }
        public int puntos { get; set; }
        public string tiempo { get; set; }
        public int pCorrectas { get; set; }
        public int pIncorrectas { get; set; }
    }
}
