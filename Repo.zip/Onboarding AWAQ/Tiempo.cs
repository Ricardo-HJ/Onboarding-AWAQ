﻿namespace Onboarding_AWAQ
{
    public class Tiempo
    {
        public string tiempo {  get; set; }
        public string unidad { get; set; }
    }
}
